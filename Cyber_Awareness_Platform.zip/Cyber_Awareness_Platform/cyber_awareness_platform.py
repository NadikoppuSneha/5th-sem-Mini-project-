from flask import Flask, render_template, request
import re

cyber_platform = Flask(__name__)


# --------------------------------------------------
# HOME PAGE
# --------------------------------------------------

@cyber_platform.route("/")
def home():

    return render_template(
        "cyber_awareness_home.html"
    )


# --------------------------------------------------
# CYBER AWARENESS
# --------------------------------------------------

@cyber_platform.route("/cyber-awareness")
def cyber_awareness():

    return render_template(
        "cyber_awareness.html"
    )


# --------------------------------------------------
# URL SAFETY CHECKER
# --------------------------------------------------

@cyber_platform.route(
    "/url-safety-checker",
    methods=["GET", "POST"]
)
def url_safety_checker():

    risk = None
    reasons = []

    if request.method == "POST":

        url = request.form.get("url", "")

        suspicious_words = [
            "login",
            "verify",
            "free",
            "winner",
            "prize",
            "urgent",
            "account",
            "claim"
        ]

        score = 0

        if not url.startswith("https://"):

            score += 2

            reasons.append(
                "URL does not use HTTPS."
            )

        for word in suspicious_words:

            if word in url.lower():

                score += 1

                reasons.append(
                    "Suspicious keyword found: "
                    + word
                )

        if len(url) > 100:

            score += 1

            reasons.append(
                "URL is unusually long."
            )

        if score >= 4:

            risk = "HIGH"

        elif score >= 2:

            risk = "MEDIUM"

        else:

            risk = "LOW"

    return render_template(
        "url_safety_checker.html",
        risk=risk,
        reasons=reasons
    )


# --------------------------------------------------
# PASSWORD STRENGTH CHECKER
# --------------------------------------------------

@cyber_platform.route(
    "/password-strength-checker",
    methods=["GET", "POST"]
)
def password_strength_checker():

    strength = None
    suggestions = []

    if request.method == "POST":

        password = request.form.get(
            "password",
            ""
        )

        score = 0

        if len(password) >= 8:

            score += 1

        else:

            suggestions.append(
                "Use at least 8 characters."
            )

        if re.search(r"[A-Z]", password):

            score += 1

        else:

            suggestions.append(
                "Add at least one uppercase letter."
            )

        if re.search(r"[a-z]", password):

            score += 1

        else:

            suggestions.append(
                "Add at least one lowercase letter."
            )

        if re.search(r"[0-9]", password):

            score += 1

        else:

            suggestions.append(
                "Add at least one number."
            )

        if re.search(
            r"[^A-Za-z0-9]",
            password
        ):

            score += 1

        else:

            suggestions.append(
                "Add at least one special character."
            )

        if score <= 2:

            strength = "WEAK"

        elif score <= 4:

            strength = "MEDIUM"

        else:

            strength = "STRONG"

    return render_template(
        "password_strength_checker.html",
        strength=strength,
        suggestions=suggestions
    )


# --------------------------------------------------
# PHISHING DETECTION PORTAL
# --------------------------------------------------

@cyber_platform.route(
    "/phishing-detection",
    methods=["GET", "POST"]
)
def phishing_detection():

    risk = None
    reasons = []

    if request.method == "POST":

        message = request.form.get(
            "message",
            ""
        )

        message_lower = message.lower()

        score = 0


        # Urgent language

        urgent_words = [
            "urgent",
            "immediately",
            "act now",
            "verify now",
            "account will be blocked"
        ]

        for word in urgent_words:

            if word in message_lower:

                score += 1

                reasons.append(
                    "Urgent or threatening language detected."
                )

                break


        # Password or login information

        if (
            "password" in message_lower
            or "login details" in message_lower
        ):

            score += 1

            reasons.append(
                "The message asks for login or password information."
            )


        # OTP

        if "otp" in message_lower:

            score += 1

            reasons.append(
                "The message asks for an OTP."
            )


        # Banking information

        banking_words = [
            "bank account",
            "credit card",
            "debit card",
            "bank details",
            "card number"
        ]

        for word in banking_words:

            if word in message_lower:

                score += 1

                reasons.append(
                    "The message requests financial information."
                )

                break


        # Prize or reward

        scam_words = [
            "winner",
            "prize",
            "lottery",
            "free gift",
            "congratulations"
        ]

        for word in scam_words:

            if word in message_lower:

                score += 1

                reasons.append(
                    "Prize or reward-related language detected."
                )

                break


        # Website link

        if (
            "http://" in message_lower
            or "https://" in message_lower
            or "www." in message_lower
        ):

            score += 1

            reasons.append(
                "The message contains a website link."
            )


        # Risk calculation

        if score >= 4:

            risk = "HIGH"

        elif score >= 2:

            risk = "MEDIUM"

        else:

            risk = "LOW"


    return render_template(
        "phishing_detection.html",
        risk=risk,
        reasons=reasons
    )


# --------------------------------------------------
# AI CYBER ASSISTANT
# --------------------------------------------------

@cyber_platform.route(
    "/ai-cyber-assistant",
    methods=["GET", "POST"]
)
def ai_cyber_assistant():

    answer = None

    if request.method == "POST":

        question = request.form.get(
            "question",
            ""
        )

        question_lower = question.lower()


        if "phishing" in question_lower:

            answer = (
                "Phishing is a cyber attack where attackers "
                "use fake emails, messages or websites to "
                "trick users into sharing sensitive information. "
                "Do not click suspicious links or share passwords "
                "and OTPs."
            )


        elif "password" in question_lower:

            answer = (
                "Use a strong and unique password with a "
                "combination of uppercase letters, lowercase "
                "letters, numbers and special characters. "
                "Avoid reusing the same password on different "
                "websites."
            )


        elif "otp" in question_lower:

            answer = (
                "Never share your OTP with anyone. Legitimate "
                "organizations should not ask you to reveal "
                "your OTP."
            )


        elif (
            "fake website" in question_lower
            or "fake site" in question_lower
        ):

            answer = (
                "Check the website address carefully before "
                "entering information. Look for HTTPS, verify "
                "the domain name and avoid websites received "
                "through suspicious messages."
            )


        elif "scam" in question_lower:

            answer = (
                "Be careful with unexpected messages asking "
                "for money, passwords, OTPs or personal "
                "information. Verify the sender before taking "
                "any action."
            )


        elif (
            "cyber security" in question_lower
            or "cybersecurity" in question_lower
        ):

            answer = (
                "Cybersecurity means protecting computers, "
                "networks, accounts and personal information "
                "from unauthorized access, attacks and scams."
            )


        else:

            answer = (
                "Stay safe online by using strong passwords, "
                "enabling two-factor authentication, avoiding "
                "suspicious links and never sharing passwords "
                "or OTPs."
            )


    return render_template(
        "ai_cyber_assistant.html",
        answer=answer
    )


# --------------------------------------------------
# CYBER QUIZ
# --------------------------------------------------

@cyber_platform.route(
    "/cyber-quiz",
    methods=["GET", "POST"]
)
def cyber_quiz():

    score = None

    if request.method == "POST":

        score = 0


        # Question 1

        if request.form.get("q1") == "correct":

            score += 1


        # Question 2

        if request.form.get("q2") == "correct":

            score += 1


        # Question 3

        if request.form.get("q3") == "correct":

            score += 1


        # Question 4

        if request.form.get("q4") == "correct":

            score += 1


        # Question 5

        if request.form.get("q5") == "correct":

            score += 1


    return render_template(
        "cyber_quiz.html",
        score=score
    )


# --------------------------------------------------
# RUN PROJECT
# --------------------------------------------------

if __name__ == "__main__":

    cyber_platform.run(
        debug=True
    )